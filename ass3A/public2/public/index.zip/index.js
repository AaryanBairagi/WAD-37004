document.getElementById('empForm').addEventListener('submit' , (event)=>{
    event.preventDefault();
    alert('Form Submitted')
})